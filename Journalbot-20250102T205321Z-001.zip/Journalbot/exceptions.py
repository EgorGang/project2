class JournalError(Exception):
    """
    Базовое исключение для ошибок в журнале.
    """
    pass